
package hospital_management;

public class Hospital_Management {

   
    public static void main(String[] args) {
       
    }
    
}
